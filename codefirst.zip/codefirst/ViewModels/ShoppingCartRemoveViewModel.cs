﻿using System.Linq;
using System.Web;
using System;
using System.Collections.Generic;


namespace OpenOrderFramework.ViewModel
{
    public class ShoppingCartRemoveViewModel
    {
        public string Message { get; set; }
        public decimal CartTotal { get; set; }
        public int CartCount { get; set; }
        public int ItemCount { get; set; }
        public int DeleteId { get; set; }
    }
}