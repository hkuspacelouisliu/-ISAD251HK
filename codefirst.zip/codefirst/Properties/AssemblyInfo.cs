﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// set of attributes. Change these attribute values to modify the information
// associate an assembly.
[assembly: AssemblyTitle("OpenOrderFramework")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("OpenOrderFramework")]
[assembly: AssemblyCopyright("Copyright ©  2014")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]


[assembly: ComVisible(false)]

// As following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("5fb57d37-410e-4b72-8d21-2c45887d3dcf")]

// Version information for an assembly consists of the following four values:

// You can specify all the values or you can default the Revision and Build Numbers

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
