﻿using System.Web.Optimization;

namespace OpenOrderFramework
{
    public class BundleConfig
    {
        //visit to :http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                    "~/Scripts/jquery-{version}.js",
                    "~/Scripts/card.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                   "~/Scripts/jquery.validate*"));

            // Can use development ver of Modernizr to develop and learn. 
            // ready for the production, use the build tool http://modernizr.com to pick only the test you needs.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                   "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                  "~/Scripts/bootstrap.js",
                   "~/Scripts/bootstrap-datepicker.js",
                   "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                  "~/Content/bootstrap.css",
                  "~/Content/variables.less",
                  "~/Content/bootswatch.less",
                  "~/Content/site.css"));
        }
    }
}
