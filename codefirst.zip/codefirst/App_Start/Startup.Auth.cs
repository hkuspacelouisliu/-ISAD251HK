﻿using OpenOrderFramework.Models;
using Owin;
using System;

using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin;
using Microsoft.Owin.Security.Cookies;
using Microsoft.Owin.Security.Google;


namespace OpenOrderFramework {
    public partial class Startup {
    
        public void ConfigureAuth(IAppBuilder app) {

            // Config  db context, user manager or role manager can use a single instance every request
            app.CreatePerOwinContext(ApplicationDbContext.Create);
            app.CreatePerOwinContext<ApplicationUserManager>(ApplicationUserManager.Create);
            app.CreatePerOwinContext<ApplicationRoleManager>(ApplicationRoleManager.Create);

            // Enable the application to use a cookie to store information for the signed in user
            // Config the sign in cookie
            app.UseCookieAuthentication(new CookieAuthenticationOptions {

                AuthenticationType = DefaultAuthenticationTypes.ApplicationCookie,
                LoginPath = new PathString("/Account/Login"),

                Provider = new CookieAuthenticationProvider {

                    // Enables the application to validate the security stamp when the user logs in.
                    // security feature which is used when you change a password or add an external login to your account.  
                    OnValidateIdentity = SecurityStampValidator.OnValidateIdentity<ApplicationUserManager, ApplicationUser>(

                        validateInterval: TimeSpan.FromMinutes(30),

                        regenerateIdentity: (manager, user) => user.GenerateUserIdentityAsync(manager))
                }

            });
            app.UseExternalSignInCookie(DefaultAuthenticationTypes.ExternalCookie);

            // Enables the application to temporarily store user information when they are verifying the second factor in the two-factor authentication process.
            app.UseTwoFactorSignInCookie(DefaultAuthenticationTypes.TwoFactorCookie, TimeSpan.FromMinutes(5));

            // Enable the application therefore remember second login verification a factor
            // when you check the option, your next step of verification during the login process will be remaner on a device when you logged in from..
        
            app.UseTwoFactorRememberBrowserCookie(DefaultAuthenticationTypes.TwoFactorRememberBrowserCookie);

            //    clientId: "",
            //    clientSecret: "");

            //   consumerKey: "",
            //   consumerSecret: "");

            //app.UseFacebookAuthentication(
      

            //app.UseGoogleAuthentication();
            //Not working currently
            GoogleAuthenticationOptions options = new GoogleAuthenticationOptions();
            options.AuthenticationMode = Microsoft.Owin.Security.AuthenticationMode.Active;
            app.UseGoogleAuthentication();
        }
    }
}