﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Infor about assembly is controll through as following
[assembly: AssemblyTitle("OpenOrderFramework.Tests")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("OpenOrderFramework.Tests")]
[assembly: AssemblyCopyright("Copyright ©  2020")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Settinga ComVisible to false make the types in assembly is not visible
[assembly: ComVisible(false)]

//  following GUID as the ID of the typelib if  assignment is exposed COM
[assembly: Guid("00b9ea1c-86ac-495d-8ebb-63056df03656")]

[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
